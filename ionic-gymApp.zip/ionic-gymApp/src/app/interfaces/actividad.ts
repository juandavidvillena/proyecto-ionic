export interface Actividad {
    id: number;
    title: string;
    description: string;
    lvls: number;
    categoria:string;
}
