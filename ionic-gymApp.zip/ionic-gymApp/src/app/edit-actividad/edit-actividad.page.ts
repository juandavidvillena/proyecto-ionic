import { Component, OnInit } from '@angular/core';
import { Actividad } from '../interfaces/actividad';
import { ActividadService } from '../services/actividad.service';
import { NavController, AlertController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit-actividad',
  templateUrl: './edit-actividad.page.html',
  styleUrls: ['./edit-actividad.page.scss'],
})
export class EditActividadPage implements OnInit {

  actividad: Actividad;
  edit = false;
  private lvl1 = false;
  private lvl2 = false;
  private lvl3 = false;

  constructor(
    private activatedRoute: ActivatedRoute,
    private actividadService: ActividadService,
    private navController: NavController,
    private alertController: AlertController) {

    this.actividad = {
      id: this.actividadService.actividadCounter,
      title: '',
      description: '',
      lvls: 1,
      categoria: ''
    };
  }

  ngOnInit() {

    const id = this.activatedRoute.snapshot.paramMap.get('id');

    if (id) {
      this.edit = true;
      this.actividad = this.actividadService.getActividadById(+id);
    }

    switch (this.actividad.lvls) {
      case 1:
        this.lvl1 = true;
        break;
      case 2:
        this.lvl1 = true;
        this.lvl2 = true;
        break;
      case 3:
        this.lvl1 = true;
        this.lvl2 = true;
        this.lvl3 = true;
        break;
      default:
    }
  }

  saveActividad(act: Actividad) {
    console.log(this.actividad.title);
    if(this.actividad.description != '' && this.actividad.title != ''){
      if (this.edit) {
        this.actividadService.saveActividad(this.actividad).then(() => this.navController.goBack(true),
          (error) => console.error('Error al guardar: ' + error)
        );
      } else {
        this.actividadService.newActividad(this.actividad).then(() => this.navController.goBack(true),
          (error) => console.error('Error al guardar: ' + error)
        );
      }
    }else{
      this.falloBlanco('¡¡¡¡ Atención!!!!','Para crear una tarea necesitas tener un titulo y una descripción');
    }
  }

  setLvl1() {
    this.lvl1 = true;
    this.lvl2 = false;
    this.lvl3 = false;
    this.actividad.lvls = 1;
  }

  setLvl2() {
    this.lvl1 = true;
    this.lvl2 = true;
    this.lvl3 = false;
    this.actividad.lvls = 2;
  }

  setLvl3() {
    this.lvl1 = true;
    this.lvl2 = true;
    this.lvl3 = true;
    this.actividad.lvls = 3;
  }

  setCat1(){
    this.actividad.categoria = "Alto";
  }
  
  setCat2(){
    this.actividad.categoria = "Medio";
  }
  
  setCat3(){
    this.actividad.categoria = "Maximo";
  }

  valorDescription(valor:string){
    this.actividad.description = valor;
  }
  async falloBlanco(header: string, message: string) {

    const alert = await this.alertController.create({
      header: header,
      message: message,
      buttons: [
        {
          text: 'Entendido',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {
          }
        }
      ]
    });
    await alert.present();
  }
}
