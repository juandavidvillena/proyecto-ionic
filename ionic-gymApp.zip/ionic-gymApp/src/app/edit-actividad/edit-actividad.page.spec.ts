import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditActividadPage } from './edit-actividad.page';

describe('EditActividadPage', () => {
  let component: EditActividadPage;
  let fixture: ComponentFixture<EditActividadPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditActividadPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditActividadPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
