import { Injectable } from '@angular/core';
import { Actividad } from '../interfaces/actividad';
import { Storage } from '@ionic/storage';

@Injectable({
  providedIn: 'root'
})
export class ActividadService {

  actividades: Actividad[] = [];
  lvl1: Actividad[] = [];
  lvl2: Actividad[] = [];
  lvl3: Actividad[] = [];
  actividadCounter = 0;
  orderAsc = true;

  constructor(private storage: Storage) {

  }

  getActividades(): Promise<Actividad[]> {
    this.storage.get('this.actividadCounter').then(data => { if (data) { this.actividadCounter = data } });
    return this.storage.get('actividades').then(
      data => {
        if (data) {this.lvl3 = data.filter(act => act.lvls === 3),
          this.lvl2 = data.filter(act => act.lvls === 2),
          this.lvl1 = data.filter(act => act.lvls === 1)
          if(this.orderAsc) {
            this.actividades = this.lvl1.concat(this.lvl2).concat(this.lvl3);
          } else {
            this.actividades = this.lvl3.concat(this.lvl2).concat(this.lvl1);
          }
          return this.actividades;
        }
      });
  }

  saveActividad(act): Promise<Actividad[]> { // devuelve una promesa
    this.actividades[this.actividades.findIndex(actividad => actividad.id === act.id)] = act;
    return this.storage.set('actividades', this.actividades);
  }

  newActividad(act): Promise<Actividad[]> {
    this.actividades.push(act);
    this.actividadCounter++;
    return this.storage.set('actividades', this.actividades).then(() =>
      this.storage.set('actividadCounter', this.actividadCounter)
    ); // devolver promesa
  }

  deleteActividad(id: number): Promise<Actividad[]> {
    this.actividades = this.actividades.filter(act => act.id !== id);
    return this.storage.set('actividades', this.actividades);
  }

  getActividadById(id: number): Actividad {
    return this.actividades.find(act => act.id === id);
  }
}