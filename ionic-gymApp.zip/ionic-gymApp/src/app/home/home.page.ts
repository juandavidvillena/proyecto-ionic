import { Component, OnInit } from '@angular/core';
import { ActividadService } from '../services/actividad.service';
import { Actividad } from '../interfaces/actividad';
import { AlertController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

  actividades: Actividad[] = [];

  constructor(
    private actividadService: ActividadService,
    private alertController: AlertController,
    private navController: NavController) { }

  ngOnInit() {

  }

  ionViewWillEnter() {
    this.actividadService.getActividades().then(data => this.actividades = data);
  }

  async deleteDialogo(title: string, id: number) {

    const alert = await this.alertController.create({
      header: 'Borrar Entrenamiento',
      message: '¿Estás seguro que quiere borrar el entremaniento <strong>' + title + '</strong>?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {
          }
        }, {
          text: 'Aceptar',
          handler: () => {
            this.actividadService.deleteActividad(id).then(
              () => this.actividadService.getActividades().then(
                data => this.actividades = data)
            );
          }
        }
      ]
    });

    await alert.present();
  }
  editTodo(id: number) {
    this.navController.navigateForward('/edit/' + id)
  }

  /*changeOrder() {
    if (this.todoService.orderAsc === false) {
      this.todoService.orderAsc = true;
      console.log('esto esta a true');
      this.todoService.getTodos();
    } else {
      this.todoService.orderAsc = false;
      console.log('esto esta a false');
      this.todoService.getTodos();
    }
    
  }*/

  ascendente() {
    this.actividadService.orderAsc = true;
    this.actividadService.getActividades();
    this.ionViewWillEnter();
  }

  descendiente() {
    this.actividadService.orderAsc = false;
    this.actividadService.getActividades();
    this.ionViewWillEnter();
  }
}
